# SYSC3303A3

SYSC 3303 A3 - Real-Time Concurrent Systems - Term Project

## Deliverable Locations

* UML documents are in the project_details folder.
* Unit test files are in the test folder.
* Source files are in the scr folder.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

Required software:

* Java
* Eclipse

### Installing

Extract the zip file.

### Testing

These instructions will help you test the project.
Make sure that **test.csv** hasn't moved from the root folder **SYSC3303A3**.
You can also edit **test.csv** to add or remove floors for more testing.

#### Running the Project using cmd or powershell

Navigate to the root folder of the project (replace /path/to with the proper path).

```bash
cd /path/to/L3G5_milestone_3
```

Run the jar file.

```bash
java -jar sysc3303.jar
```

After, follow the instructions in the console. You will need to run Initializer 3 times.

#### Running the project with Eclipse

Open Eclipse.

Add the folder "SYSC3303A3" to eclipse as a project.

1. File > Open Project From The File System
2. Click Directory
3. Navagate to the project
4. Click Finished

Navigate to the scr folder in eclipse

* src > default package

Run "Initializer.java" as a java application

* Right Click "Initializer.java" > Run As > Java Application

After, follow the instructions in the console. You will need to run Initializer 3 times.

## Authors

* Dorian Wang - [dustan1](https://github.com/dustan1)
* John Singer - [Jsings](https://github.com/Jsings)
* Nafisul Haque - [nafisulhaque](https://github.com/nafisulhaque)
* Tanner Trautrim - [EmberNight](https://github.com/EmberNight)