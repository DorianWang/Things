

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ElevatorDataTest {
    @Test
    public void addElevatorDestinationUP() {
    	// Test insertion
    	ElevatorData ed = new ElevatorData(1);
    	Integer[] result = new Integer[5];
    	Integer[] expected = {0,2,9,1,4};
    	
    	ed.addElevatorDestination(0, Scheduler.UP);
    	ed.addElevatorDestination(2, Scheduler.UP);
    	ed.addElevatorDestination(9, Scheduler.UP);
    	ed.addElevatorDestination(1, Scheduler.UP);
    	ed.addElevatorDestination(4, Scheduler.UP);
    	
    	ed.getUpDestinations().toArray(result);
    	
    	for (int i = 0; i < 5; i++) {
    		assertEquals(expected[i], result[i]);
    	}
    }
    
    @Test
    public void addElevatorDestinationDOWN() {
    	// Test insertion
    	ElevatorData ed = new ElevatorData(1);
    	Integer[] result = new Integer[5];
    	Integer[] expected = {0,2,9,1,4};
    	
    	ed.addElevatorDestination(0, Scheduler.DOWN);
    	ed.addElevatorDestination(2, Scheduler.DOWN);
    	ed.addElevatorDestination(9, Scheduler.DOWN);
    	ed.addElevatorDestination(1, Scheduler.DOWN);
    	ed.addElevatorDestination(4, Scheduler.DOWN);
    	
    	ed.getDownDestinations().toArray(result);
    	
    	for (int i = 0; i < 5; i++) {
    		assertEquals(expected[i], result[i]);
    	}
    }
    
    @Test
    public void removeElevatorDestination() {
    	// Test past empty
    	ElevatorData ed = new ElevatorData(1);
    	Integer[] testNumbers = {0,2,9,1,4,1,6};
    	
    	ed.addElevatorDestination(0, Scheduler.UP);
    	ed.addElevatorDestination(2, Scheduler.UP);
    	ed.addElevatorDestination(9, Scheduler.DOWN);
    	ed.addElevatorDestination(1, Scheduler.UP);
    	ed.addElevatorDestination(4, Scheduler.UP);
    	
    	assertTrue(ed.removeElevatorDestination(testNumbers[0], Scheduler.UP));
    	assertTrue(ed.removeElevatorDestination(testNumbers[1], Scheduler.UP));
    	assertTrue(ed.removeElevatorDestination(testNumbers[2], Scheduler.DOWN));
    	assertTrue(ed.removeElevatorDestination(testNumbers[3], Scheduler.UP));
    	assertTrue(ed.removeElevatorDestination(testNumbers[4], Scheduler.UP));
    	assertFalse(ed.removeElevatorDestination(testNumbers[5], Scheduler.DOWN));
    	assertFalse(ed.removeElevatorDestination(testNumbers[6], Scheduler.UP));
    }
    
    @Test
    public void hasDestination() {
    	// Test while empty and full
    	ElevatorData ed = new ElevatorData(1);
    	Integer[] testNumbers = {0,2,9,1,4,1,6};
    	
    	assertEquals(false, ed.hasDestination(testNumbers[1], Scheduler.DOWN));
    	
    	ed.addElevatorDestination(0, Scheduler.UP);
    	ed.addElevatorDestination(2, Scheduler.UP);
    	ed.addElevatorDestination(9, Scheduler.DOWN);
    	ed.addElevatorDestination(1, Scheduler.UP);
    	ed.addElevatorDestination(4, Scheduler.DOWN);
    	
    	assertTrue(ed.hasDestination(testNumbers[0], Scheduler.UP));
    	assertTrue(ed.hasDestination(testNumbers[1], Scheduler.UP));
    	assertTrue(ed.hasDestination(testNumbers[2], Scheduler.DOWN));
    	assertTrue(ed.hasDestination(testNumbers[3], Scheduler.UP));
    	assertTrue(ed.hasDestination(testNumbers[4], Scheduler.DOWN));
    	assertFalse(ed.hasDestination(testNumbers[5], Scheduler.DOWN));
    	assertFalse(ed.hasDestination(testNumbers[6], Scheduler.DOWN));
    }
}
