
import static org.junit.jupiter.api.Assertions.*;
import java.net.DatagramPacket;
import org.junit.jupiter.api.Test;

public class NetworkingTest {

	@Test
	public void getByteArrayRealLength() {
		// Test insertion
		Networking n = new Networking(1);

		int expected = 17;
		int result = n.getByteArrayRealLength(n.createMsg("10", "1", "31", "42", "1", 1));
		assertEquals(expected, result);

		expected = 14;
		result = n.getByteArrayRealLength(n.createMsg("1", "1", "3", "4", "1", 1));
		assertEquals(expected, result);

		expected = 34;
		result = n.getByteArrayRealLength(n.createMsg("10809", "10908", "30801", "42980", "09081", 1));
		assertEquals(expected, result);

		expected = 15;
		result = n.getByteArrayRealLength(n.createMsg("", "", null, "42", "1", 1));
		assertEquals(expected, result);
	}

	@Test
	public void createMsgScheduler() {
		// Test insertion
		Networking n = new Networking(1);

		byte[] expected = {0, Networking.ACK, ' ', 49, 48, ' ', 49, ' ', 51, 49, ' ', 52, 50, ' ', 49, ' ', 0 };
		byte[] result = n.createMsg("10", "1", "31", "42", "1", Networking.ACK);

		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i], result[i]);
		}

		expected = new byte[]{0, Networking.SCHEDULER, ' ', 49, 48, ' ', 49, ' ', 51, 49, ' ', 52, 50, 52, ' ', 49, ' ', 0 };
		result = n.createMsg("10", "1", "31", "424", "1", Networking.SCHEDULER);

		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i], result[i]);
		}

		expected = new byte[]{0, Networking.FLOOR, ' ', 49, 48, ' ', 49, ' ', 51, 49, ' ', 52, 50, ' ', 49, 53, ' ', 0 };
		result = n.createMsg("10", "1", "31", "42", "15", Networking.FLOOR);

		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i], result[i]);
		}

		expected = new byte[]{0, Networking.ELEVATOR, ' ', 49, 48, 49, ' ', 49, ' ', 51, 49, ' ', 52, 50, ' ', 49,' ', 0 };
		result = n.createMsg("101", "1", "31", "42", "1", Networking.ELEVATOR);
		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i], result[i]);
		}
		
		expected = new byte[]{0, Networking.ELEVATOR_REQUEST, ' ', 49, 48, 49, ' ', 49, ' ', 51, 49, ' ', 52, 50, ' ', 49, ' ', 0 };
		result = n.createMsg("101", "1", "31", "42", "1", Networking.ELEVATOR_REQUEST);
		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i], result[i]);
		}
	}

	@Test
	public void getDirection() {
		Networking n = new Networking(1);
		byte[] temp = n.createMsg("10", "1", "31", "1", "1", 1);
		DatagramPacket p = new DatagramPacket(temp, temp.length);
		int expected = 1;
		assertEquals(expected, n.getDirection(p));

		temp = n.createMsg("10", "1", "31", "-1", "1", 1);
		p = new DatagramPacket(temp, temp.length);
		expected = -1;
		assertEquals(expected, n.getDirection(p));

		temp = n.createMsg("10", "1", "31", "0", "1", 1);
		p = new DatagramPacket(temp, temp.length);
		expected = 0;
		assertEquals(expected, n.getDirection(p));
	}

	@Test
	public void getFloor() {
		Networking n = new Networking(1);
		byte[] temp = n.createMsg("10", "1", "31", "42", "1", 1);
		DatagramPacket p = new DatagramPacket(temp, temp.length);
		int expected = 1;
		assertEquals(expected, n.getFloor(p));

		temp = n.createMsg("10", "231", "31", "42", "1", 2);
		p = new DatagramPacket(temp, temp.length);
		expected = 231;
		assertEquals(expected, n.getFloor(p));

		temp = n.createMsg("10", "432", "31", "42", "1", 3);
		p = new DatagramPacket(temp, temp.length);
		expected = 432;
		assertEquals(expected, n.getFloor(p));
	}
	
	@Test
	public void getcurrFloor() {
		Networking n = new Networking(1);
		byte[] temp = n.createMsg("10", "1", "31", "42", "1", 1);
		DatagramPacket p = new DatagramPacket(temp, temp.length);
		int expected = 31;
		assertEquals(expected, n.getCurrFloor(p));

		temp = n.createMsg("10", "231", "1", "42", "1", 2);
		p = new DatagramPacket(temp, temp.length);
		expected = 1;
		assertEquals(expected, n.getCurrFloor(p));

		temp = n.createMsg("10", "432", "55323", "42", "1", 3);
		p = new DatagramPacket(temp, temp.length);
		expected = 55323;
		assertEquals(expected, n.getCurrFloor(p));
	}
	
	@Test
	public void getTime() {
		Networking n = new Networking(1);
		byte[] temp = n.createMsg("10", "1", "31", "42", "24:00", 1);
		DatagramPacket p = new DatagramPacket(temp, temp.length);
		String expected = "24:00";
		assertTrue(expected.equals(n.getTime(p)));

		temp = n.createMsg("10", "231", "31", "42", "12:00", 2);
		p = new DatagramPacket(temp, temp.length);
		expected = "12:00";
		assertTrue(expected.equals(n.getTime(p)));
		
		temp = n.createMsg("10", "432", "31", "42", "12:12", 3);
		p = new DatagramPacket(temp, temp.length);
		expected = "12:12";
		assertTrue(expected.equals(n.getTime(p)));
	}

	@Test
	public void getIdentification() {
		Networking n = new Networking(2);

		byte[] temp = n.createMsg("10", "1", "31", "42", "1", 1);
		DatagramPacket p = new DatagramPacket(temp, temp.length);
		int expected = 10;
		assertEquals(expected, n.getIdentification(p));

		temp = n.createMsg("1", "80", "78", "76", "322", 2);
		p = new DatagramPacket(temp, temp.length);
		expected = 1;
		assertEquals(expected, n.getIdentification(p));

		temp = n.createMsg("101", "78", "31", "80", "1", 1);
		p = new DatagramPacket(temp, temp.length);
		expected = 101;
		assertEquals(expected, n.getIdentification(p));
	}

	@Test
	public void verifyAck() {
		Networking n = new Networking(Networking.ELEVATOR);

		byte[] temp = n.createMsg("10", "1", "31", "42", "1", Networking.ACK);
		DatagramPacket p = new DatagramPacket(temp, n.getByteArrayRealLength(temp));
		assertTrue(n.verifyAck(p));

		temp = n.createMsg("20", "1", "3", "492", "10", Networking.ACK);
		p = new DatagramPacket(temp, n.getByteArrayRealLength(temp));
		assertTrue(n.verifyAck(p));
	}
}
