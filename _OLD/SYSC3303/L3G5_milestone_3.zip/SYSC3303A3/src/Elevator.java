import java.net.DatagramPacket;

public class Elevator implements Runnable {
	private final static int CLOSE = 2420; // Time for closing doors.
	private final static int OPEN = 3210; // Time for opening doors.
	private final static int ACCELERATION = 1810; // Time for acceleration doors.
	private final static int DECELERATION = 2290; // Time for deceleration doors.
	private final static int FLOOR_TRAVEL = 1230; // Time for travel at max speed doors.
	private final static int LOADING = 9530; // Time for loading for 3 people.
	
	// Time multiplier used to adjust the time scale.
	private final static double TIME_MULTIPLYER = 0.1;
	
	// Elevator Directions
	private final static int UP = 1;
	private final static int DOWN = -1;
	
	// Elevator States
	private final static int IDLE = 0;
	private final static int DOORS_CLOSED = 1;
	private final static int MOTOR_STARTED = 2;
	private final static int STOP_REQUESTED = 3;
	private final static int MOTOR_STOPPED = 4;
	private final static int DOORS_OPENED = 5;
	private final static int LOADED = 6;
	
	private int direction;
	private int currFloor;
	private int floorToStopAt;
	private int state;
	
	private String name;


	Networking n;

	Elevator (Networking n) {
		this.n = new Networking(Networking.MODE_ELEVATOR); 
		this.n.initElevatorFloor();
		direction = IDLE;
		currFloor = 0;
		floorToStopAt = 0;
		state = -1;
		name = "";
	}

	/**
	 * Prints the loading message.
	 */
	private synchronized void loading() {
		System.out.printf("%s: Loading.\n", getName());
	}
	
	/**
	 * Prints the closed door message.
	 */
	private synchronized void closeDoors() {
		if(getCurrFloor() < getFloorToStopAt()) {
			setDirection(UP);
		} else if (getCurrFloor() > getFloorToStopAt()){
			setDirection(DOWN);
		}
		
		System.out.printf("%s: Closing Doors.\n", getName(), getFloorToStopAt());
	}

	/**
	 * Prints the openDoors Message.
	 */
	private synchronized void openDoors() {
		System.out.printf("%s: Opening Doors.\n", getName());
	}

	/**
	 * Prints the stop motor message.
	 */
	private synchronized void stopMotor() {
		System.out.printf("%s: Stopping Motor at floor: %d.\n", getName(), getFloorToStopAt());
	}

	/**
	 * Prints the start motor message.
	 * 
	 * @return true if the motor started.
	 */
	private synchronized boolean startMotor() {
		if(getCurrFloor() < getFloorToStopAt()) {
			System.out.printf("%s: Requested at floor: %d... Going up.\n", getName(), getFloorToStopAt());
			setDirection(UP);
			return true;
		} else if (getCurrFloor() > getFloorToStopAt()){
			System.out.printf("%s: Requested at floor: %d... Going down.\n", getName(), getFloorToStopAt());
			setDirection(DOWN);
			return true;
		} else {
			System.out.printf("%s: Requested at floor: %d... Current Floor.\n", getName(), getFloorToStopAt());
			return false;
		}
	}
	
	/**
	 * Used to put the thread to sleep and vary the times.
	 * 
	 * @param milliSeconds
	 */
	private synchronized void sleep(int milliSeconds) {
		try {
			Thread.sleep((int) (milliSeconds * TIME_MULTIPLYER));
		} catch (InterruptedException e) {}
	}

	/**
	 * Causes the elevator to wait for new work.
	 */
	private synchronized void waitForWork() {
		setDirection(IDLE);
		while (currFloor == floorToStopAt) {
			try {
				wait();
			} catch (InterruptedException e) {}
		}
	}
	
	/**
	 * Checks if the elevator needs to stop.
	 * 
	 * @return true if the elevator needs to stop
	 */
	private boolean requestStop() {
		if (getCurrFloor() < getFloorToStopAt()) {
			setCurrFloor(getCurrFloor() + 1);
		} else {
			setCurrFloor(getCurrFloor() - 1);
		}
		
		
		if(getCurrFloor() == getFloorToStopAt()) {
			System.out.printf("%s: Current floor: %d... Verfied stop required.\n", getName(), getCurrFloor());
			return true;
		} else {
			System.out.printf("%s: Current floor: %d... Stop not required.\n", getName(), getCurrFloor());
			return false;
		}
	}
	
	/**
	 * Allows another thread to wake the waiting elevator
	 */
	public synchronized void wake() {
		notify();
	}

	/**
	 * @return the floor
	 */
	public synchronized int getCurrFloor() {
		return currFloor;
	}

	/**
	 * @param floor the floor to set
	 */
	public synchronized void setCurrFloor(int floor) {
		this.currFloor = floor;
	}

	/**
	 * @return the floorToStopAt
	 */
	public synchronized int getFloorToStopAt() {
		return floorToStopAt;
	}

	/**
	 * @param floorToStopAt the floorToStopAt to set
	 */
	public synchronized void setFloorToStopAt(int floorToStopAt) {
		this.floorToStopAt = floorToStopAt;
	}

	/**
	 * @return the name
	 */
	public synchronized String getName() {
		return name;
	}

	/**
	 * Sets the elevators name using the current thread name
	 * 
	 * @param name the name to set
	 */
	private synchronized void setName() {
		name = Thread.currentThread().getName();
	}
	
	/**
	 * @return the direction
	 */
	public synchronized int getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public synchronized void setDirection(int direction) {
		this.direction = direction;
	}

	private void checkStatus() {
		switch(state) {
		case DOORS_CLOSED:
			if (startMotor())
				state = MOTOR_STARTED;
			else {
				state = LOADED; // Probably will need to change later, but this should fix the stalling
			}
			sleep(ACCELERATION);
			break;
		case MOTOR_STARTED:
			if (requestStop()){ 
				state = STOP_REQUESTED;
			} else {
				sleep(FLOOR_TRAVEL);
			}
			closeDoors();
			sleep(CLOSE);
			break;
		case STOP_REQUESTED:
			stopMotor();
			sleep(DECELERATION);
			state = MOTOR_STOPPED;
			break;
		case MOTOR_STOPPED:
			openDoors();
			sleep(OPEN);
			state = DOORS_OPENED;
			break;
		case DOORS_OPENED:
			loading();
			sleep(LOADING);
			state = LOADED;
			break;
		case LOADED:
			Integer currFloor = getCurrFloor();
			Integer direction = getDirection();
			
			
			byte[] msg=n.createMsg(getName(),null, currFloor.toString(), direction.toString(), null, Networking.ELEVATOR_REQUEST);
			DatagramPacket p = n.sendReceive(msg,msg.length,45431);

    		if (n.verifyAck(p)) {
    			state = -1;
    		} else {
    			floorToStopAt = n.getFloor(p);
    			state = DOORS_CLOSED;
    		}
			break;
		default:
			state = LOADED;
			break;
		}
	}
	
	@Override
	public void run() {
		System.out.println("Elevator started");
		setName();
		
		while(true) {
			checkStatus();
		}
	}
}
