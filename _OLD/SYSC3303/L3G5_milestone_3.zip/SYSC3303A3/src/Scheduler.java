import java.net.DatagramPacket;
import java.util.ArrayList;

public class Scheduler implements Runnable {
	// Global Variables
	public final static int CHECK_FOR_WORK = 0;
	public final static int BUTTON = 1;
	public final static int FLOOR = 2;

	public final static int UP = 1;
	public final static int ERROR = 0;
	public final static int IDLE = 0;
	public final static int DOWN = -1;

	private ArrayList<ElevatorData> elevatorData;
	
	private Networking netElevators;
	private Networking netFloor;
	
	private int state;
	DatagramPacket p;

	/**
	 * Created the main scheduler object.
	 * Creates the elevator and floor threads.
	 * 
	 * @param numOfElevators number of elevators required
	 * @param numOfFloors number of floors required
	 */
	public Scheduler(Networking netElevators, Networking netFloor) {
		elevatorData = new ArrayList<ElevatorData>();
		state = 0;
		
		this.netElevators = netElevators;
		this.netFloor = netFloor;
		
		Thread thread_elevator = new Thread(netElevators);
		Thread thread_floor = new Thread(netFloor);
		
		thread_elevator.start();
		thread_floor.start();
	}
	
	/**
	 * Checks if the scheduler has a record of the elevator
	 * if it doesn't create a record and return the elevator
	 * index. 
	 * 
	 * @param elevatorNumber The elevators given number.
	 * @return true if the elevator exists.
	 */
	private ElevatorData getElevatorData(int elevatorNumber) {
		boolean exists = false;
		
		for (int i = 0; i < elevatorData.size(); i++) {
			if (elevatorNumber == elevatorData.get(i).getElevatorNumber()) {
				exists = true;
				return elevatorData.get(i);
			}
		}
		
		if (!exists) {
			elevatorData.add(new ElevatorData(elevatorNumber));
		}
		
		return elevatorData.get(elevatorData.size() - 1);
	}

	/**
	 * Algorithm to add new destinations to elevators base on a best
	 * to worst case structure. Best case the elevator is already heading
	 * the right direction. Second best case elevator is idle. Worst case
	 * elevator is going the incorrect direction. When the worst case is 
	 * selected it will compare worst case elevators to find the best one.
	 * 
	 * @param requestFloor the new destination to add
	 * @param userDirection with the floor wants to go up or down
	 */
	private void addDestinationF(int requestFloor, int userDirection, int port) {
		// 0 Elevator same direction on the way (best case)
		// 1 Elevator is idle (middle case)
		// 2 Elevator has the least number of destinations (worst case)
		// 3 Case not determined yet
		int selectedReason = 3;
		int currentReason = 3;
		int selected = -1;

		if (userDirection != ERROR) {
			for (int i = 0; i < elevatorData.size(); i++) {
				ElevatorData data = elevatorData.get(i);
				int otwFloor = data.getTravelingToFloor();
				int lastKnownDirection = data.getDirection();

				// If one of the elevators already have the destination ignore
				// the button press.
				if(data.hasDestination(requestFloor, lastKnownDirection)) {
					return;
				}
				
				// Best case elevator idle
				// Second best elevator is heading towards the floor
				if (lastKnownDirection == IDLE) {
					currentReason = 0;
				} else if (lastKnownDirection == userDirection) {
					if (userDirection == DOWN && otwFloor > requestFloor) {
						currentReason = 1;
					} else if (userDirection == UP && otwFloor < requestFloor) {
						currentReason = 1;
					} 
				}
				
				// Worst case add the destination to the least busy elevator
				if (currentReason == -1) {
					if (userDirection == UP) {
						if (data.getUpDestinations().size() <= elevatorData.get(selected).getUpDestinations().size()) {
							currentReason = 2;
						}
					} else if (userDirection == UP) {
						if (data.getDownDestinations().size() <= elevatorData.get(selected).getDownDestinations().size()) {
							currentReason = 2;
						}
					}
				}

				// If the is a better elevator for the job select it.
				if (currentReason < selectedReason) {
					selectedReason = currentReason;
					selected = i;
				} else if (currentReason == selectedReason) {
					selected = i;
				}
			}

			System.out.printf("Scheduler: Floor added work.\n");
			elevatorData.get(selected).addElevatorDestination(requestFloor, userDirection);
			
			byte[] byt = netElevators.createMsg(null, null, null, null, null, Networking.ACK);
			netElevators.send(byt, netElevators.getByteArrayRealLength(byt), port);
		}
	}

	/**
	 * When the elevator buttons are pushed add it to that elevators destinations.
	 * 
	 * @param identifier elevator the button was push on.
	 * @param floor	floor the user wants to go to.
	 * @param direction 
	 */
	private void addDestinationE(int identifier, int floor, int currFloor, int port) {
		if (currFloor < floor) {
			elevatorData.get(identifier).addElevatorDestination(floor, UP);
		} else {
			elevatorData.get(identifier).addElevatorDestination(floor, DOWN);
		}
		
		byte[] byt = netElevators.createMsg(null, null, null, null, null, Networking.ACK);
		netElevators.send(byt, netElevators.getByteArrayRealLength(byt), port);
	}
	
	/**
	 * Schedules the elevator to go to its next destination.
	 * 
	 * @param name Name of the Elevator.
	 * @param identifier The array index of the elevator.
	 * @param floor The current floor the elevator needs to travel too.
	 * @param direction Direction the elevator is currently going.
	 */
	private int scheduleWork(int identifier, int floor, int direction, int port) {
		int msgType = 0;
		int nextFloor = 0;
		
		if (elevatorData.get(identifier).getUpDestinations().isEmpty() && 
				elevatorData.get(identifier).getDownDestinations().isEmpty()) {
			System.out.printf("Scheduler: Elevator %d Has no work available.\n", identifier);
			msgType = Networking.ACK;
		} else {
			nextFloor = elevatorData.get(identifier).nextDestination(floor, direction);
			System.out.printf("Scheduler: Elevator %d's New Destination is: %d.\n", identifier, nextFloor);
			msgType = Networking.SCHEDULER;
		}

		byte[] byt = netElevators.createMsg(null, Integer.toString(nextFloor), null, null, null, Networking.ELEVATOR_REQUEST);
		netElevators.send(byt, netElevators.getByteArrayRealLength(byt), port);
		
		if (msgType == Networking.ACK) {
			nextFloor = Integer.MAX_VALUE;
		}
		
		return nextFloor;
	}

	/**
	 * Is the main method does all the reading from the status of the
	 * floors and elevators and calls the proper functions based on
	 * what is happening at the time.
	 */
	@SuppressWarnings("null")
	private synchronized void checkStatus() {		
		int id = 0;
		int direction = 0;
		int currFloor =  0;
		int floor = 0;
		
		
		switch(state) {
		case 0:
			if (!elevatorData.isEmpty()) {
				p = netFloor.getIncomingPacket();
				if (p != null) {
					addDestinationF(netFloor.getFloor(p), netFloor.getDirection(p), p.getPort());
				}
			}
			state++;
			break;
		case 1:
			p = netElevators.getIncomingPacket();
			if (p == null) {
				state = -1;
			} else if (netElevators.getType(p) == (byte) Networking.ELEVATOR_REQUEST) {
				state = 2;
			} else if (netElevators.getType(p) == (byte) Networking.ELEVATOR) {
				state = 3;
			}
			break;
		case 2:
			id = netElevators.getIdentification(p);
			direction = netElevators.getDirection(p);
			currFloor =  netElevators.getCurrFloor(p);
			
			ElevatorData ed = getElevatorData(id);
			
			ed.setDirection(direction);
			ed.setTravelingToFloor(scheduleWork(id, currFloor, direction, p.getPort()));
			state = -1;
			break;
		case 3:
			id = netElevators.getIdentification(p);
			direction = netElevators.getDirection(p);
			currFloor =  netElevators.getCurrFloor(p);
			floor =  netElevators.getCurrFloor(p);
			
			getElevatorData(id);
			
			addDestinationE(id, floor, currFloor, p.getPort());
			state = -1;
			break;
		default:
			state = 0;
			break;
		}
	}

	/**
	 * runnable main method for the thread. starts the elevator and floor
	 * threads and starts the loop.
	 */
	@Override
	public void run() {
		while(true) {
			checkStatus();
		}
	}
}
