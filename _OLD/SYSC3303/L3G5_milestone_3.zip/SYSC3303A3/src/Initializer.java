import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Initializer {
	public static void main(String[] args) {
		System.out.println("Which system you would like to initialize.");
		System.out.printf("Enter %d for Scheduler\n", Networking.MODE_SCHEDULER);
		System.out.printf("Enter %d for Elevator\n", Networking.MODE_ELEVATOR);
		System.out.printf("Enter %d for Floor\n", Networking.MODE_FLOOR);
		System.out.println("Enter anything else to quit.");
		System.out.println("Enter your option here: ");
		
        BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
        String s = null;
        
        try {
			s = buffer.readLine();
		} catch (IOException e) {
			System.exit(1);
			e.printStackTrace();
		}

        if (Integer.toString(Networking.MODE_SCHEDULER).contentEquals(s)) {
        	System.out.println("Initializing Scheduler");
        	
        	Networking n1 = new Networking(Networking.MODE_SCHEDULER);
        	Networking n2 = new Networking(Networking.MODE_SCHEDULER);
        	
        	n1.initScheduler(0);
        	n2.initScheduler(1);
        	
        	Thread t = new Thread(new Scheduler(n1, n2), "Scheduler");
        	t.start();
        	
        } else if (Integer.toString(Networking.MODE_ELEVATOR).contentEquals(s)) {
        	System.out.println("How many elevators?");
        	System.out.println("Enter a positive number > 0.");
        	System.out.println("Enter anything else to quit.");
        	
        	int numOfElevators = 0;
            try {
    			s = buffer.readLine();
    		} catch (IOException e) {
    			System.exit(1);
    			e.printStackTrace();
    		}
        	
            try {
            	numOfElevators = Integer.decode(s);
            } catch (NumberFormatException e) {
            	System.out.println("Exiting - Elevator initialization cancelled");
            	System.exit(0);
            }
            
            if (numOfElevators < 1) {
            	System.out.println("Exiting - Can't have negative elevators.");
            	System.exit(0);
            }
        	
        	System.out.println("Initializing Elevator(s)");

        	Thread t[] = new Thread[numOfElevators];
        	
        	Networking n = new Networking(Networking.MODE_ELEVATOR);
        	n.initElevatorFloor();
        	
        	for (int i = 0; i < numOfElevators; i++) {
        		t[i] = new Thread(new Elevator(n), Integer.toString(i));
        		t[i].start();
        	}
        } else if (Integer.toString(Networking.MODE_FLOOR).contentEquals(s)) {
        	System.out.println("Initializing Floor");

        	Thread t = new Thread(new Floor(1), "1");
        	t.start();
        } else {
        	System.out.println("Exiting");
        	System.exit(0);
        }
	}
}
