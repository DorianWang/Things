
//For Timestamps
import java.time.Instant;

//For logging
import java.util.logging.Level;
import java.util.logging.Logger;

//For file IO
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.DatagramPacket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.util.concurrent.atomic.AtomicBoolean;;

public class Floor implements Runnable{

	private int floorNumber; // What floor this is, as in what number would be put in front of the elevator
	
	private String inputFile;
	//private String outputFile;
	private AtomicBoolean isRunning;

	private Networking adapter;
	private Thread worker;

	private final static String INPUT_FILE = "test.csv";
	//private final static String OUTPUT_FILE = "Floor_Error_Log";
	private final static Logger LOGGER = Logger.getLogger(Floor.class.getName()); //https://www.vogella.com/tutorials/Logging/article.html

	/**
	 * The class currently does not use the outputFile string, but it may be used for logging.
	 * The inputFile string is for the csv input.
	 */
	Floor(int floorNumber){
		this.adapter = new Networking(Networking.MODE_FLOOR); 
		adapter.initElevatorFloor();
		this.floorNumber = floorNumber;
		isRunning = new AtomicBoolean(false);

		LOGGER.setLevel(Level.ALL);
		this.inputFile = INPUT_FILE;
		//this.outputFile = OUTPUT_FILE;
	}

	/**
	 * This function attempts to load the file with path inputFile as a csv file with Delimiter " ".
	 * It will wait at least 100 ms between row reads and always waits for the buffer to be retrieved.
	 * It places the floor number and the direction as a number of -1, 0, 1 for down, null and up.
	 */
	public void loadTests() {

		try (Scanner csvfile = new Scanner(new FileReader(this.inputFile))){
			while (csvfile.hasNext() && this.isRunning.get()) {
			    try (Scanner rowScanner = new Scanner(csvfile.nextLine())) {
			        rowScanner.useDelimiter(" ");
			        List<String> tokens = new ArrayList<>(); 

			        while (rowScanner.hasNext()) {
			        	tokens.add(rowScanner.next());
			        }

			        int floor = Integer.parseInt(tokens.get(1));
			        int direction = 0;


			        if(tokens.get(2).toLowerCase().contains("up")) {
			        	direction = 1;
			        } else if(tokens.get(2).toLowerCase().contains("down")) {
			        	direction = -1;
			        } else {
			        	//Ow
			        	LOGGER.severe("Could not find up/down direction");
			        	direction = 0;
			        }

			        byte[] newmsg = this.adapter.createMsg(Integer.valueOf(this.floorNumber).toString(), Integer.valueOf(floor).toString(), null, Integer.valueOf(direction).toString(), Long.valueOf(Instant.now().getEpochSecond()).toString(), 2);
			        DatagramPacket recieved = this.adapter.sendReceive(newmsg, newmsg.length, 54323); // Port number is Networking.SCHEDULER_FLOOR_PORT
			        
	        		if (this.adapter.verifyAck(recieved) == false) {
	        			System.out.println("Error with acknowledgement");
	        			// Oops
	        		}
			        
			    }
			}
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}


		//LOGGER.warning("Inside loadTests");
		//LOGGER.info(String.valueOf(Instant.now().getEpochSecond()));

	}


	/**
	 * This is the run function, please use start() if you wish to run the thread.
	 * Currently, this class only loads and sends the floor info into the buffer.
	 */
	@Override
	public void run() {
		this.isRunning.set(true);
		// TODO Auto-generated method stub
		while (this.isRunning.get()) {
			loadTests();
			isRunning.set(false); // For now, just stop after getting all the tests
		}

	}

	public synchronized void start() {
		if (this.isRunning.get() == false) {
			worker = new Thread(this);
			worker.start();
		}
	}

	public synchronized void stop() {
		this.isRunning.set(false);
	}

	public boolean getRunning() {
		return this.isRunning.get();
	}

}


