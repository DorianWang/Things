
import java.util.Iterator;
import java.util.LinkedList;

public class ElevatorData {
	private int direction;
	private int elevatorNumber;
	private int travelingToFloor;
	private LinkedList<Integer> upDestinations;
	private LinkedList<Integer> downDestinations;

	/**
	 * Creates a new ElevatorData object with the default values set.
	 * 
	 * @param elevator
	 */
	ElevatorData(int elevatorNum) {
		this.direction = 0;
		this.elevatorNumber = elevatorNum;
		this.travelingToFloor = 0;
		this.upDestinations = new LinkedList<Integer>();
		this.downDestinations = new LinkedList<Integer>();
	}


	/**
	 * Adds a floor to a list of destinations.
	 * 
	 * @param destination is the new floor to add to the destination list
	 * @param direction 
	 */
	public void addElevatorDestination(int destination, int direction) {
		if (direction == Scheduler.UP) {
			upDestinations.add(destination);
		} else {
			downDestinations.add(destination);
		}
	}

	/**
	 * Checks is a floor is in the destination list if there is
	 * remove it from the list and return true.
	 * 
	 * @param destination floor to check if it is in the list.
	 * @return Returns true is there was an occurrence
	 */
	public boolean removeElevatorDestination(int destination, int direction) {
		if (direction == 1) {
			return upDestinations.removeFirstOccurrence(destination);
		} else {
			return downDestinations.removeFirstOccurrence(destination);
		}
	}

	/**
	 * Checks is the floor is in the destination list.
	 * 
	 * @param destination floor to check if it is in the list.
	 * @param direction 
	 * @return Returns true is there was an occurrence
	 */
	public boolean hasDestination(int destination, int direction) {
		if (direction == Scheduler.UP) {
			for (Iterator<Integer> i = upDestinations.iterator(); i.hasNext();) {
				if (i.next() == destination) {
					return true;
				}
			}
		} else {
			for (Iterator<Integer> i = downDestinations.iterator(); i.hasNext();) {
				if (i.next() == destination) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Used to find the best floor for the elevator to travel too next.
	 * 
	 * @param floor Current floor of the elevator.
	 * @param direction Current direction of the elevator.
	 * @return The next floor for the elevator to travel too.
	 */
	public int nextDestination(int floor, int direction) {
		boolean updated = false;
		int nextFloor = 0;
		int newDirection = 0;
		
		// Tries to find an elevator in the up direction
		if (direction == Scheduler.UP || direction == Scheduler.IDLE) {
			for (Iterator<Integer> i = upDestinations.iterator(); i.hasNext();) {
				int listFloor = i.next();

				if (listFloor > floor && !updated) {
					nextFloor = listFloor;
					updated = true;
				} else if ((listFloor > floor && listFloor < nextFloor)) {
					nextFloor = listFloor;
				}
			}

			newDirection = Scheduler.UP;
			
			// if it can't find one in the up direction it will look for one in the down
			if (!updated) {
				for (Iterator<Integer> i = downDestinations.iterator(); i.hasNext();) {
					int listFloor = i.next();

					if (listFloor < floor && !updated) {
						nextFloor = listFloor;
						updated = true;
					} else if ((listFloor < floor && listFloor > nextFloor)) {
						nextFloor = listFloor;
					}
				}
				newDirection = Scheduler.DOWN;
			}
			
		// Tries to find an elevator in the down direction
		} else if (direction == Scheduler.DOWN) {
			for (Iterator<Integer> i = downDestinations.iterator(); i.hasNext();) {
				int listFloor = i.next();

				if (listFloor < floor && !updated) {
					nextFloor = listFloor;
					updated = true;
				} else if ((listFloor < floor && listFloor > nextFloor)) {
					nextFloor = listFloor;
				}
			}
			newDirection = Scheduler.DOWN;

			// if it can't find one in the down direction it will look for one in the up
			if (!updated) {
				for (Iterator<Integer> i = upDestinations.iterator(); i.hasNext();) {
					int listFloor = i.next();

					if (listFloor > floor && !updated) {
						nextFloor = listFloor;
						updated = true;
					} else if ((listFloor > floor && listFloor < nextFloor)) {
						nextFloor = listFloor;
					}
				}
				newDirection = Scheduler.UP;
			}
		}

		removeElevatorDestination(nextFloor, newDirection);

		if (!updated) {nextFloor = -100;}
		return nextFloor;
	}

	/**
	 * Standard Getter and Setters are below this line
	 */

	/**
	 * @return the elevatorNumber
	 */
	public synchronized int getElevatorNumber() {
		return elevatorNumber;
	}


	/**
	 * @param elevatorNumber the elevatorNumber to set
	 */
	public synchronized void setElevatorNumber(int elevatorNumber) {
		this.elevatorNumber = elevatorNumber;
	}


	/**
	 * @return the elevatorDestinations
	 */
	public LinkedList<Integer> getUpDestinations() {
		return upDestinations;
	}

	/**
	 * @param elevatorDestinations the elevatorDestinations to set
	 */
	public void setUpDestinations(LinkedList<Integer> elevatorDestinations) {
		this.upDestinations = elevatorDestinations;
	}


	
	/**
	 * @return the downDestinations
	 */
	public LinkedList<Integer> getDownDestinations() {
		return downDestinations;
	}


	/**
	 * @param downDestinations the downDestinations to set
	 */
	public void setDownDestinations(LinkedList<Integer> downDestinations) {
		this.downDestinations = downDestinations;
	}


	public int getTravelingToFloor() {
		return travelingToFloor;
	}


	public void setTravelingToFloor(int travelingToFloor) {
		this.travelingToFloor = travelingToFloor;
	}


	public int getDirection() {
		return direction;
	}


	public void setDirection(int direction) {
		this.direction = direction;
	}

	
}
