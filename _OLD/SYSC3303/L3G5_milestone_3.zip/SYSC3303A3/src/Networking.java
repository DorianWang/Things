import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;

public class Networking implements Runnable {
	public static final int SCHEDULER_ELEVATOR_PORT = 45431;
	public static final int SCHEDULER_FLOOR_PORT = 54323;
	public static final int RECEIVE_LEN = 38; // TODO Change to perfect size once message format is sorted out. 

	public static final int ACK = 1;
	public static final int ELEVATOR = 2;
	public static final int ELEVATOR_REQUEST = 3;
	public static final int FLOOR = 4;
	public static final int SCHEDULER = 5;
	
	// In case we want to change numbers, and to remind us what they are.
	public static final int MODE_SCHEDULER = 1;
	public static final int MODE_ELEVATOR = 2;
	public static final int MODE_FLOOR = 3;

	private DatagramSocket receive;
	private DatagramSocket transmission;

	private ArrayList<DatagramPacket> incoming;

	private boolean initialized;
	private int mode; // 1 = Scheduler, 2 = Elevator, 3 = floor

	Networking(int mode) {
		initialized = false;

		receive = null;
		transmission = null;

		incoming = new ArrayList<DatagramPacket>();

		switch(mode) {
		case MODE_SCHEDULER:
			this.mode = SCHEDULER;
			break;
		case MODE_ELEVATOR:
			this.mode = ELEVATOR;
			break;
		case MODE_FLOOR:
			this.mode = FLOOR;
			break;
		default:
			System.out.println("Bad mode value.");
			System.exit(1);
		}
	}

	/**
	 * Creates a new DatagramSocket socket and returns it. If the
	 * port specified is out of range it will bind to a random port.
	 * If creation fails exit the program.
	 * 
	 * @param port Sets the socket port.
	 * @return Initialized DatagramSocket.
	 */
	private DatagramSocket newSocket(int port) {
		DatagramSocket ds = null;

		try {
			if (port < 0 || port > 65535) {
				// Create Socket to use for sending
				// Binds to random port.
				ds = new DatagramSocket();
			} else {
				// Create Socket to use for sending
				// Binds to specified port.
				ds = new DatagramSocket(port);
			}

		} catch (SocketException e) { 
			// Socket Creation failed
			e.printStackTrace();
			System.exit(1);
		}

		return ds;
	}
	
	/**
	 * Parses a message array and returns the bytes between
	 * two bytes that represent a space.
	 * 
	 * @param p packet with the data
	 * @param numOfSpaces space to start at
	 * @return Byte[]
	 */
	private byte[] parse(DatagramPacket p, int numOfSpaces) {
		byte[] msg = p.getData();
		
		byte[] byt = new byte[5];
		int length = 0;

		int spaceCount = 0;
		byte space = ' ';

		for (int i = 0; i < p.getLength(); i++) {
			if (msg[i] == space) {
				spaceCount++;
			} else {
				if (spaceCount == numOfSpaces) {
					byt[length] = msg[i];
					length++;
				} else if (spaceCount > numOfSpaces) {
					break;
				}
			}
		}

		if (byt[4] == (byte) 0) {
			byt = new byte[] {byt[0], byt[1], byt[2], byt[3]};
		}

		if (byt[3] == (byte) 0) {
			byt = new byte[] {byt[0], byt[1], byt[2]};
		}
		
		if (byt[2] == (byte) 0) {
			byt = new byte[] {byt[0], byt[1]};
		}

		if (byt[1] == (byte) 0) {
			byt = new byte[] {byt[0]};
		}
		
		return byt;
	}

	/**
	 * Waits for a packet to be received.
	 * 
	 * @return the received packet
	 */
	private DatagramPacket receivePacket() {
		byte[] data = new byte[RECEIVE_LEN]; // packet size is already known
		DatagramPacket packet = new DatagramPacket(data, RECEIVE_LEN);

		try {
			if (mode == SCHEDULER) {
				System.out.println("receive Started.");
				receive.receive(packet);
				System.out.println("receive Finished.");
			} else {
				System.out.println("transmission Finished.");
				transmission.receive(packet);
				System.out.println("transmission Finished.");
			}
		} catch (IOException e) {
			System.out.println("receivePacket failed.");
			e.printStackTrace();
			System.exit(1);
		}

		return packet;
	}

	/**
	 * States for handling networking for the scheduler.
	 */
	private void runScheduler() {
		DatagramPacket packet = null;

		while(true) {
			packet = receivePacket();

			synchronized(this) {
				incoming.add(packet);
			}
		}
	}

	/**
	 * Creates a packet and sends it to the specified system Client port.
	 * 
	 * @param msg Message to send.
	 * @param port port to send the message too.
	 */
	private void sendPacket (byte[] msg, int length, int port) {
		DatagramPacket packet;

		try {
			packet = new DatagramPacket(msg, length, InetAddress.getLocalHost(), port);
			transmission.send(packet);
		} catch (IOException e) {
			System.out.println("sendPacket failed.");
			e.printStackTrace();
			System.exit(1);
		}
	}

	/**
	 * Create a message to send information to the scheduler from the elevator.
	 * 
	 * @param elevatorNum the elevator that sent the message
	 * @param floor the floor number if the button was pushed
	 * @param buttonPress if the button was pushed
	 * @return
	 * @throws IOException 
	 */
	public byte[] createMsg(String identifier, String floor, String currFloor, String direction, String time, int msgType) {
		byte[] b = new byte[RECEIVE_LEN];

		if (identifier == null || " ".equals(identifier) || "".equals(identifier)) {
			identifier = "#";
		}
		
		if (floor == null || " ".equals(floor) || "".equals(floor)) {
			floor = "#";
		}
		
		if (currFloor == null || " ".equals(currFloor) || "".equals(currFloor)) {
			currFloor = "#";
		}
		
		if (direction == null || " ".equals(direction) || "".equals(direction)) {
			direction = "#";
		}
		
		if (time == null || " ".equals(time) || "".equals(time)) {
			time = "#";
		}
		
		byte[] ID = identifier.getBytes();
		byte[] f = floor.getBytes();
		byte[] cf = currFloor.getBytes();
		byte[] d = direction.getBytes();
		byte[] t = time.getBytes();

		b[0] = (byte) 0;
		b[1] = (byte) msgType;
		b[2] = ' ';

		int byteArraySize = 3;

		
		// Add the elevator number to the byte array
		for (int i = byteArraySize; i < (ID.length + byteArraySize); i++) {
			b[i] = ID[i - byteArraySize];
		}

		byteArraySize += ID.length;
		b[byteArraySize] = ' ';
		byteArraySize++;
		
		// Add the elevator number to the byte array
		for (int i = byteArraySize; i < (f.length + byteArraySize); i++) {
			b[i] = f[i - byteArraySize];
		}

		byteArraySize += f.length;
		b[byteArraySize] = ' ';
		byteArraySize++;
		
		// Add the elevator number to the byte array
		for (int i = byteArraySize; i < (cf.length + byteArraySize); i++) {
			b[i] = cf[i - byteArraySize];
		}

		byteArraySize += cf.length;
		b[byteArraySize] = ' ';
		byteArraySize++;
		
		// Add the elevator number to the byte array
		for (int i = byteArraySize; i < (d.length + byteArraySize); i++) {
			b[i] = d[i - byteArraySize];
		}

		byteArraySize += d.length;
		b[byteArraySize] = ' ';
		byteArraySize++;
		
		// Add the elevator number to the byte array
		for (int i = byteArraySize; i < (t.length + byteArraySize); i++) {
			b[i] = t[i - byteArraySize];
		}

		byteArraySize += t.length;
		b[byteArraySize] = ' ';
		byteArraySize++;
		b[byteArraySize] = (byte) 0;

		return b;
	}

	/**
	 * Gets the real length of the array to pass to
	 * a DatagramPacket.
	 * 
	 * @param b Byte[] message
	 * @return the real length
	 */
	public int getByteArrayRealLength(byte[] b) {
		int length = 0;
		int zeroCount = 0;
		byte zero = 0;

		for (int i = 0; i < b.length; i++) {
			length++;

			if (b[i] == zero) {
				zeroCount++;
			}

			if (zeroCount == 2) {
				break;
			}
		}

		return length;
	}

	/**
	 * Returns the direction from the packet.
	 * 
	 * @param p Packet to parse
	 * @return The direction
	 */
	public int getDirection(DatagramPacket p) {
		return Integer.decode(new String(parse(p, 4)));
	}

	/**
	 * Returns the floor number from the packet.
	 * 
	 * @param packet Packet to parse
	 * @return The floor
	 */
	public int getFloor(DatagramPacket p) {
		return Integer.decode(new String(parse(p, 2)));
	}

	/**
	 * Returns the current floor number from the packet.
	 * 
	 * @param packet Packet to parse
	 * @return The floor
	 */
	public int getCurrFloor(DatagramPacket p) {
		return Integer.decode(new String(parse(p, 3)));
	}
	
	/**
	 * Returns the sender from the packet.
	 * 
	 * @param p Packet to parse
	 * @return The sender
	 */
	public int getIdentification(DatagramPacket p) {
		return Integer.decode(new String(parse(p, 1)));
	}
	
	/**
	 * Returns the time from the packet.
	 * 
	 * @param p Packet to parse
	 * @return The sender
	 */
	public String getTime(DatagramPacket p) {
		return new String(parse(p, 5));
	}
	
	/**
	 * Returns the message type from the packet.
	 * 
	 * @param p Packet to parse
	 * @return The sender
	 */
	public byte getType(DatagramPacket p) {
		return p.getData()[1];
	}
	
	/**
	 * Removes a packet from the incoming list
	 * 
	 * @return a packet
	 */
	public synchronized DatagramPacket getIncomingPacket() {
		if(incoming.isEmpty()) {
			return null;
		}
		
		return incoming.remove(0);
	}

	/**
	 * Initializes the class to work with the scheduler.
	 * 
	 * listen = 0 Listening for elevators
	 * listen = 1 Listening for floors
	 * 
	 * @param listen what to listen for
	 * @return if initialization was successful
	 */
	public synchronized boolean initScheduler(int listen) {
		if (initialized || mode != SCHEDULER) {
			return false;
		}

		switch(listen) {
		case 0:
			receive = newSocket(SCHEDULER_ELEVATOR_PORT);
			break;
		case 1:
			receive = newSocket(SCHEDULER_FLOOR_PORT);
			break;
		default:
			return false;
		}

		transmission = newSocket(-1);
		initialized = true;

		return true;
	}

	/**
	 * Initializes the class to work with the elevator
	 * or floor classes.
	 * 
	 * @return if initialization was successful
	 */
	public synchronized boolean initElevatorFloor() {
		if (initialized || !(mode == ELEVATOR || mode == FLOOR)) {
			return false;
		}

		transmission = newSocket(-1);
		initialized = true;

		return true;
	}

	/**
	 * Used to send a message to a specific port.
	 * 
	 * @param msg
	 * @param length
	 * @param port
	 */
	public void send(byte[] msg, int length, int port) {
		if (mode == SCHEDULER) {
			sendPacket(msg, length, port);
		} else {
			System.out.println("Incorrect mode to use send().");
			System.exit(1);
		}
	}

	/**
	 * Used to send a message to a specific port.
	 * Then wait to receive a response.
	 * 
	 * @param msg
	 * @param length
	 * @param port
	 */
	public synchronized DatagramPacket sendReceive(byte[] msg, int length, int port) {
		DatagramPacket packet = null;

		if (mode != SCHEDULER) {
			sendPacket(msg, length, port);
			packet = receivePacket();
		} else {
			System.out.println("Incorrect mode to use sendReceive().");
			System.exit(1);
		}
		return packet;
	}
	
	/**
	 * Verifies that the packet is only acknowledgment.
	 * 
	 * @param packet to check for ack.
	 * @return true if ack.
	 */
	public boolean verifyAck(DatagramPacket packet) {
		if (packet.getLength() > 38) {
			return false;
		}

		return (ACK == packet.getData()[1]);
	}

	@Override
	public void run() {
		if(!initialized) {
			System.out.println("Not initialized failing.");
			System.exit(1);
		}

		if (mode == SCHEDULER) {
			runScheduler();
		} else {
			System.out.println("Bad mode value.");
			System.exit(1);
		}
	}
}