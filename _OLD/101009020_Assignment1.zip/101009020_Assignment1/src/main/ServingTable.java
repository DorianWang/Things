package main;



public class ServingTable{


	private Ingredient[] currentIngredients = new Ingredient[2];
	private volatile int numLeaguePlayers;
	
	ServingTable() {
        
		this.currentIngredients[0] = null;
		this.currentIngredients[1] = null;
		this.numLeaguePlayers = 0;
		
		
	}
	
	public synchronized void put(Ingredient one, Ingredient two) {
			while(this.currentIngredients[0] != null && this.currentIngredients[1] != null) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		
		this.currentIngredients[0] = one;
		this.currentIngredients[1] = two;
		notifyAll();
	}
	
	public synchronized Ingredient[] get(Ingredient currentIngredient) {
		while(this.currentIngredients[0] == null || this.currentIngredients[1] == null || this.currentIngredients[0] == currentIngredient || this.currentIngredients[1] == currentIngredient) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		Ingredient[] templist = {this.currentIngredients[0], this.currentIngredients[1]};
		this.currentIngredients[0] = null; this.currentIngredients[1] = null;
		notifyAll();
		return templist;
	}
	
	public synchronized void addLeaguePlayer() {
		this.numLeaguePlayers += 1;
		System.out.println("Made League player #: " + this.numLeaguePlayers);
	}
	
	public int getLeaguePlayer() {
		return this.numLeaguePlayers;
	}
	
	
	//https://www.baeldung.com/java-thread-stop
	public static void main(String[] args) throws InterruptedException {
		ServingTable table = new ServingTable();

		//System.out.println(Colours.ANSI_CYAN.value + "Test Test");
		
		//Three chefs, each with its own ingredient
		Chef[] chefs = new Chef[3];
		chefs[0] = new Chef(Ingredient.SALT, table);
		chefs[1] = new Chef(Ingredient.SEA_SALT, table);
		chefs[2] = new Chef(Ingredient.RAGE, table);
		
		Agent agent = new Agent(table);
		
		System.out.println("Starting Threads!");
		
		for (int i = 0; i < 3; i++) {
			chefs[i].start();
		}
		
		agent.start();
		
		// While there have been less than 19 league players made, the program sleeps for 1 millisecond
		while (table.getLeaguePlayer() < 19) {
			Thread.sleep(1);
		}
		
		agent.stop();
		
		for (int i = 0; i < 3; i++) {
			chefs[i].stop();
		}

		
		System.out.println("Stopped Threads!");
		System.exit(0);
	}

}
