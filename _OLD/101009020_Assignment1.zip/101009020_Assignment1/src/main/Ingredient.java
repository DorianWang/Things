package main;


//Ingredients for a league of legends player
public enum Ingredient {
	SALT, SEA_SALT, RAGE;
	
	public static Ingredient convertIntToIngredient(int input) {
		if (input == 0) {
			return Ingredient.SALT;
		}
		else if(input == 1) {
			return Ingredient.SEA_SALT;
		}
		else if (input == 2) {
			return Ingredient.RAGE;
		}
		else {
			return null;
		}
	}
}
