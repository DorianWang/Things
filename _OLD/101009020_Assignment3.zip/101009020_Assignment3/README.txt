How to run
Run the Intermediate program, the Server program and the Client program in that order.
Other programs using port 23 can cause the execution to fail.
Output of the programs will be through standard output (console default).
If run in Eclipse the console output limit may need to be increased or removed, as the programs will have a lot of output.

The programs can also be run by running
java -jar X.jar
with X being the program name.

All code files are in the src folder, with subfolders for each.
All UML images have been placed in the root directory of the project.

At the end the program will fail due to the bad input.

Questions
1. I think that two threads makes the implementation easier as you don't need to keep track of where things should be going
as it remains consistant within each thread, if done as suggested. My implementation is not quite as suggested.

2. I did not use the synchronized keyword in the intermediate task, but I did use a mutex to control my input buffer. My implementation requires it.
I think that synchronized is not needed in the intermediate task suggested if things go properly, with the client adding requests and then the server asking for them.
However, if the server is too slow in requesting new tasks, the intermediate will need a buffer that needs some sort of flag to protect it.