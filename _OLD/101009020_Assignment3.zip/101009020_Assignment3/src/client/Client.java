package client;

import java.io.IOException;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import java.util.UUID;
import intermediate.PacketTypes;

public class Client {
	public static final int BUFFER_SIZE = 4096; // Windows maximum path length is 260 characters, while Linux generally has a max of 4096.
	public static final int OUT_PORT = 23; // Port to be sent on, also used for telnet apparently
	
	//Using code from example echo java program
	DatagramPacket sentPacket, receivedPacket;
	DatagramSocket sendReceiveSocket;
	
	
	public byte[] generateData(boolean isRead, boolean modeNetASCII, String fileName) {
		byte[] buffer = new byte[BUFFER_SIZE];
		int index = 0; // This variable points to the next available 
		
		buffer[index++] = (byte) 0; // Add to index 0 and then increment.
		
		if (isRead) {
			buffer[index++] = (byte) 1;
		} else {
			buffer[index++] = (byte) 2;
		}
		

		byte[] nameBytes = fileName.getBytes();
		for (byte character : nameBytes) {
			buffer[index++] = character;
		}
		
		buffer[index++] = (byte) 0;

		if (modeNetASCII) {
			byte[] modeBytes = "netascii".getBytes();
			for (byte character : modeBytes) {
				buffer[index++] = character;
			}
		} else {
			byte[] modeBytes = "ocTEt".getBytes();
			for (byte character : modeBytes) {
				buffer[index++] = character;
			}
		}
		
		buffer[index++] = (byte) 0;

		byte[] result = new byte[index];
		System.arraycopy( buffer, 0, result, 0, index );
		return result;
	}
	
	/**
	 * @param packetInput An array of bytes
	 * This function takes an array of bytes which will be printed out as a string of 
	 * characters as well as a space separated line of byte values.
	 */
	public void printPacket(byte[] packetInput) {
		System.out.print("String Version of Packet: ");
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print((char)packetInput[i]);
		}
		System.out.print("\n");
		System.out.print("Byte Version of Packet: ");
		
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print(packetInput[i]);
			System.out.print(" ");
		}
		System.out.print("\n");
	}
	
	/**Creates a random file name using a uuid with .txt appended
	 * 
	 * @return a valid text file name with 40 characters, contains dashes
	 */
	private static String createFileName() {
        UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();
        return randomUUIDString + ".txt";
	}
	
	
	
	/**
	 * This function, when called, generates and sends test cases to the Intermediate class
	 * running on the same device using UDP port 23.
	 * @throws InterruptedException 
	 */
	public void runTests() throws InterruptedException {
		
		try {
			this.sendReceiveSocket = new DatagramSocket();
		} catch (SocketException e1) {
			e1.printStackTrace();
			System.exit(5);
		}
		
		// Running 10 tests with some variation of the types of valid inputs.
		for (int i = 0; i < 10; i++) {
			byte[] temp = null; // A buffer to hold the current working packet information
			if ((i % 2) == 0) { // Send a read request
				if(i % 3 == 0) {
					temp = this.generateData(false, true, createFileName());
				} else {
					temp = this.generateData(false, false, createFileName());
				}
			} else { // Send a write request
				if(i % 3 == 0) {
					temp = this.generateData(true, true, createFileName());
				} else {
					temp = this.generateData(true, false, createFileName());
				}
			}
			System.out.println("\nPacket to intermediate.");
			this.printPacket(temp);
			
			try {
				this.sentPacket = new DatagramPacket(temp, temp.length,
				        InetAddress.getLocalHost(), OUT_PORT);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(2);
			}
			
			
			try {
				sendReceiveSocket.send(this.sentPacket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(3);
			}
			
			
			temp = new byte[BUFFER_SIZE];
			receivedPacket = new DatagramPacket(temp, temp.length);
		    try {
		          // Block until a datagram is received via sendReceiveSocket.  
		          sendReceiveSocket.receive(receivedPacket);
		     } catch(IOException e) {
		          e.printStackTrace();
		          System.exit(4);
		     }
		    System.out.println("Received packet from intermediate.");
		    temp = new byte[receivedPacket.getLength()];
			System.arraycopy( receivedPacket.getData(), 0, temp, 0, receivedPacket.getLength() );
		    
		    this.printPacket(temp);
		    
		    try {
				Thread.sleep((long) (100 + Math.random() % 100)); // Sleep for 100 to 200 ms
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Poll server for results from query
			while (true) {
			    System.out.println("Asking for results from intermediate.");
			    temp = PacketTypes.REQUEST_RESULTS_CLIENT.toBytes();
				try {
					this.sentPacket = new DatagramPacket(temp, temp.length,
					        InetAddress.getLocalHost(), OUT_PORT);
					sendReceiveSocket.send(this.sentPacket);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.exit(2);
				}
			

				temp = new byte[BUFFER_SIZE];
				receivedPacket = new DatagramPacket(temp, temp.length);
			    try {
			          // Block until a datagram is received via sendReceiveSocket.  
			          sendReceiveSocket.receive(receivedPacket);
			     } catch(IOException e) {
			          e.printStackTrace();
			          System.exit(4);
			     }
			    System.out.println("Received results from intermediate.");
			    temp = new byte[receivedPacket.getLength()];
				System.arraycopy( receivedPacket.getData(), 0, temp, 0, receivedPacket.getLength() );
				if (PacketTypes.checkPacket(temp) != PacketTypes.NULL_PACKET) {
					break; // It was a hit!
				}
				else
				{
					System.out.println("Taking a nap while waiting for results");
					Thread.sleep(500);
				}
			}
		    
		    this.printPacket(temp);
		}
		
		System.out.println("Doing Nonfunctional stuff!");
		byte[] nonfunctional = this.generateData(false, true, createFileName());
		nonfunctional[1] = (byte) -3;
		try {
			this.sentPacket = new DatagramPacket(nonfunctional, nonfunctional.length,
			        InetAddress.getLocalHost(), OUT_PORT);
			
			sendReceiveSocket.send(this.sentPacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(5);
		}
		
		byte[] temp = new byte[BUFFER_SIZE];
		receivedPacket = new DatagramPacket(temp, temp.length);
		
	    try {
	        // Block until a datagram is received via sendReceiveSocket or 4 seconds passes.  
	    	sendReceiveSocket.setSoTimeout(4000);
	    	sendReceiveSocket.receive(receivedPacket);
	    	
	    } catch(SocketTimeoutException e2) {
	    	System.out.println("Socket Timed Out!");
	    	return; // Like GOTO, but without GOTO
		    
	     } catch(IOException e) {
	          e.printStackTrace();
	          System.exit(4);
	     }

	     this.printPacket(receivedPacket.getData());
		
	}
	
	
	public static void main(String[] args) {
		System.out.println("Running Client");
		
		Client test = new Client();
		try {
			test.runTests();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		
		System.exit(0);
	}

}


