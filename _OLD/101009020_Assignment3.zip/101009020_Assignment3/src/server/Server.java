package server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import intermediate.PacketTypes;


public class Server {
	public static final int BUFFER_SIZE = 4096; // Windows maximum path length is 260 characters, while Linux generally has a max of 4096.
	public static final int SERVER_PORT = 69; // Port to interact with the server, used for TFTP
	public static final int OUT_PORT = 23;
	
	private static final byte[] readValue = {0, 3, 0, 1};
	private static final byte[] writeValue = {0, 4, 0, 0};
	
	DatagramSocket IOSocket;
    DatagramPacket sentPacket, receivedPacket;
	
	Server(){
		try {
			IOSocket = new DatagramSocket();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * This function checks received packet and returns an int based on what it is.
	 * @param buffer
	 * @return an integer with a value of 0 if the buffer is invalid, 1 if it is a read request, and 2 if it is a write request
	 */
	private int checkPacket(byte[] buffer) {
		if (buffer.length < 6) {
			System.out.println("Input is too short to check!");
			return 0;
		}
		int index = 2; int tempvalue = -1;
		if (buffer[0] != 0) {
			System.out.println("Input does not start with 0!");
			return 0;
		}
		
		if (buffer[1] == 1) {
			tempvalue = 1;
		} else if(buffer[1] == 2) {
			tempvalue = 2;
		} else {
			System.out.println("Input does have 1 or 2 as the second byte!");
			return 0;
		}

		
		for (;; index ++) { // Currently doesn't check if its actually a file name
			if (buffer[index] == (byte) 0) {
				break;
			}
			if (index > buffer.length - 4) {
				System.out.println("Input does not end the file name properly!");
				return 0;
			}
		}
		
		index++;
		
		for (;; index ++) { // Ditto here for the mode
			if (buffer[index] == (byte) 0) {
				break;
			}
			if (index == buffer.length - 1) {
				System.out.println("Input does not end the mode string properly!");
				return 0;
			}
		}
		if (index != buffer.length - 1) {
			System.out.println("Input does not end after the mode string!");
			return 0; // There is information after the 3rd 0, therefore packet is incorrect
		}
		
		return tempvalue;
	}
	
	
	/**
	 * 
	 * @param packetInput An array of bytes
	 * This function takes an array of bytes which will be printed out as a string of 
	 * characters as well as a space separated line of byte values.
	 */
	public void printPacket(byte[] packetInput) {
		System.out.print("String Version of Packet: ");
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print((char)packetInput[i]);
		}
		System.out.print("\n");
		System.out.print("Byte Version of Packet: ");
		
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print(packetInput[i]);
			System.out.print(" ");
		}
		System.out.print("\n");
	}
	
	
	public void run() throws IOException, InterruptedException {
		while(true) {
			
			//Making socket and sending packet
			byte[] temp = PacketTypes.REQUEST_WORK_SERVER.toBytes();
			byte[] buffer = new byte[BUFFER_SIZE];
			sentPacket = new DatagramPacket(temp, temp.length, InetAddress.getLocalHost(), OUT_PORT);
			receivedPacket = new DatagramPacket(buffer, buffer.length);
			

			System.out.println("Requesting work from intermediate:");
			try {
				IOSocket.send(sentPacket);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(2);
			}
			
			try {
				IOSocket.receive(receivedPacket);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(2);
			}
			
			
			// Trim down array to actual received amount
			byte[] input = new byte[receivedPacket.getLength()];
			System.arraycopy( buffer, 0, input, 0, receivedPacket.getLength() );
			
			System.out.println("\nReceived packet from intermediate:");
			this.printPacket(input);
			
			if (PacketTypes.checkPacket(input) == PacketTypes.NULL_PACKET) {
				System.out.println("\nNo work, napping.");
				Thread.sleep(500); // Wait a bit before asking again.
				continue;
			}

			// Checks validity of received information and then sends back a message.
			switch(this.checkPacket(input)) {
			case 0:
				throw new IOException(); // Invalid input
			case 1:
				this.sentPacket = new DatagramPacket(readValue, readValue.length,
						receivedPacket.getAddress(), OUT_PORT);
				break;
			case 2:
				this.sentPacket = new DatagramPacket(writeValue, writeValue.length,
						receivedPacket.getAddress(), OUT_PORT);
				break;
			default:
				System.exit(4); // \o.o/ I dunno how we got here
			}
			
			Thread.sleep(10 + (long)(Math.random() % 100)); // Slow it down a bit, like it was actually reading or writing files
			
			//Sending a response with results back to the intermediate
			System.out.println("Sending results to intermediate:");
			try {
				IOSocket.send(this.sentPacket);
				printPacket(sentPacket.getData());
			} catch (SocketException e) {
				e.printStackTrace();
				System.exit(5);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(6);
			}
			
			System.out.println("Waiting for acknowledgement from intermediate:");
			try {
				IOSocket.receive(receivedPacket);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(2);
			}
			input = new byte[receivedPacket.getLength()];
			System.arraycopy( buffer, 0, input, 0, receivedPacket.getLength() );
			
			System.out.println("\nReceived acknowledgement from intermediate:");
			this.printPacket(input);
			System.out.println();
			
			
			
			//My code is still a tragedy, and the world is a worse place with it existing...
		}
	}
	
	
	public static void main(String[] args) {

		System.out.println("Running Server");
		
		Server server = new Server();
		try {
			server.run();
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

}
