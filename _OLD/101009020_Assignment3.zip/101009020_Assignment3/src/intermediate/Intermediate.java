package intermediate;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class Intermediate extends Thread{
	public static final int BUFFER_SIZE = 4096; // Windows maximum path length is 260 characters, while Linux generally has a max of 4096.
	public static final int CLIENT_PORT = 23; // Port to interact with the client, also used for telnet apparently
	//public static final int SERVER_PORT = 69; // Port to interact with the server, not used for this version. All inputs should be sent to port 23.
	
	//Code used from echo server
    DatagramPacket sentPacket, receivedPacket;
    DatagramSocket serverSocket;
    
    List<DatagramPacket> queue = new LinkedList<DatagramPacket>();
    ReentrantLock queueLock = new ReentrantLock();
    
    // These two queues hold the pending responses to either the server or client.
    // They currently do not differentiate between different servers or clients.
    List<DatagramPacket> toServerQueue = new LinkedList<DatagramPacket>();
    List<DatagramPacket> toClientQueue = new LinkedList<DatagramPacket>();
    
    
    Intermediate(){
    	try {
    		serverSocket = new DatagramSocket();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
    	
    }
   
    public void addQueue(DatagramPacket input) {
    	queueLock.lock();
    	queue.add(input);
    	queueLock.unlock();
    }
    
	/**
	 * 
	 * @param packetInput An array of bytes
	 * This function takes an array of bytes which will be printed out as a string of 
	 * characters as well as a space separated line of byte values.
	 */
	public void printPacket(byte[] packetInput) {
		System.out.print("String Version of Packet: ");
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print((char)packetInput[i]);
		}
		System.out.print("\n");
		System.out.print("Byte Version of Packet: ");
		
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print(packetInput[i]);
			System.out.print(" ");
		}
		System.out.print("\n");
	}
	
	
	
    /**
     * Main function of the class, loops forever and forwards packets from clients to servers and vice versa.
     * It will also print out all packets passing through.
     */
    public void run() {
    	while (true) {
    		if (queue.isEmpty()) {
    			try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
					break;
				}
    			continue; // If there is no work, sleep for a millisecond and hope there is some next check.
    		}
    		
    		
    		try {
    			this.queueLock.lock();
    			receivedPacket = this.queue.remove(0);
    		}
    		finally {
    			this.queueLock.unlock();
    		}
    		
    		
    		
			byte[] input = receivedPacket.getData();
			
			System.out.println("\nPacket Handling Now!:");
			this.printPacket(input);
			
			PacketTypes packetType = PacketTypes.checkPacket(input);
			
			byte[] output;
			
			// Instead of using a thread each to handle each packet flow, I instead used one to accept and one to send.
			// This switch statement here sorts out what each packet should contain. From there it will sort them.
			switch(packetType) {
			case READ_REQUEST:
			case WRITE_REQUEST:
				this.toServerQueue.add(receivedPacket); // Forward this packet to the next server requesting info.
				output = PacketTypes.ACK_PACKET.toBytes();
				sentPacket = new DatagramPacket(output, output.length, receivedPacket.getAddress(), receivedPacket.getPort());
				break;
			case READ_SUCCESS:
			case WRITE_SUCCESS:
				this.toClientQueue.add(receivedPacket); // Forward this packet to the next client requesting info.
				output = PacketTypes.ACK_PACKET.toBytes();
				sentPacket = new DatagramPacket(output, output.length, receivedPacket.getAddress(), receivedPacket.getPort());
				break;
				
			case REQUEST_RESULTS_CLIENT:
				if (this.toClientQueue.size() == 0) { // If no responses from the server are in the queue, send a null message to the client.
					output = PacketTypes.NULL_PACKET.toBytes();
					sentPacket = new DatagramPacket(output, output.length, receivedPacket.getAddress(), receivedPacket.getPort());
					break;
				}
				sentPacket = this.toClientQueue.remove(0);
				sentPacket.setAddress(receivedPacket.getAddress()); sentPacket.setPort(receivedPacket.getPort());
				break;
			case REQUEST_WORK_SERVER:
				if (this.toServerQueue.size() == 0) { // If no work orders from the client are in the queue, send a null message to the server.
					output = PacketTypes.NULL_PACKET.toBytes();
					sentPacket = new DatagramPacket(output, output.length, receivedPacket.getAddress(), receivedPacket.getPort());
					break;
				}
				sentPacket = this.toServerQueue.remove(0);
				sentPacket.setAddress(receivedPacket.getAddress()); sentPacket.setPort(receivedPacket.getPort());
				break;
				
			
			default:
				System.out.println("Something is broken in packetType switch!"); // Someone sent something funny, or something got lost in the tubes
				continue;
			
			}
			
			// Send a packet back to the sender of the packet with the proper information.
			try {
				serverSocket.send(sentPacket);
			} catch (IOException e1) {
				e1.printStackTrace();
				System.exit(6);
			}

    	}
    }
	
	public static void main(String[] args) {
		System.out.println("Running Intermediate!");
		Intermediate inter = new Intermediate();
		inter.start();
		
		
		DatagramSocket receiver = null;
		try {
			receiver = new DatagramSocket(Intermediate.CLIENT_PORT);
		} catch (SocketException e) {
			System.out.println("Failed to create receiver socket");
			e.printStackTrace();
			System.exit(1);
		}
		
		//Two threads, main thread and intermediate object threads
		System.out.println("Running Second Part of Intermediate!");
		while(true) {

			//Making socket and receiving packet
			byte[] buffer = new byte[BUFFER_SIZE];
			DatagramPacket receivedPacket = new DatagramPacket(buffer, buffer.length);
			
			//Wait to get packets here
			try {
				receiver.receive(receivedPacket);
				System.out.println("Received a Packet!");
			} catch (IOException e) {
				System.out.println("Failed to create receiver socket");
				e.printStackTrace();
				break;
			}
			inter.addQueue(receivedPacket);
		}
		
		if(receiver.isClosed() == false) {
			receiver.close();
		}
		
		System.exit(0);
	}

}
