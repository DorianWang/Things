/**
 * 
 */
package intermediate;

/**
 * @author Dorian Wang
 *
 */
public enum PacketTypes {

	ACK_PACKET(new byte[]{(byte)0b11001100, (byte)0b00110011}), READ_REQUEST(new byte[]{(byte)0b00000000, (byte)0b00000001}), WRITE_REQUEST(new byte[]{(byte)0b00000000, (byte)0b00000010}),
	READ_SUCCESS(new byte[]{(byte)0b00000000, (byte)0b00000011}), WRITE_SUCCESS(new byte[]{(byte)00000000, (byte)0b00000100}), NULL_PACKET(new byte[]{(byte)0b00000000, (byte)0b00000000}),
	REQUEST_RESULTS_CLIENT(new byte[]{(byte)0b00000001, (byte)0b0000000}), REQUEST_WORK_SERVER(new byte[]{(byte)0b00000001, (byte)0b0000001});
	
	
	private final byte[] value;
	
	public byte[] toBytes() {
		return this.value;
	}
    
    private PacketTypes(byte[] value) {
    	this.value = value;
    }
    
	public static PacketTypes checkPacket(byte[] input){
		if (input.length < 2) {
			return PacketTypes.NULL_PACKET;
		}
		
		if(input[0] == 0) {
			if (input[1] == 1) {
				return PacketTypes.READ_REQUEST;
			}
			else if(input[1] == 2) {
				return PacketTypes.WRITE_REQUEST;
			}
			else if(input[1] == 3) {
				return PacketTypes.READ_SUCCESS;
			}
			else if(input[1] == 4) {
				return PacketTypes.WRITE_SUCCESS;
			}
		}
		
		if(input[0] == 1) {
			if (input[1] == 0) {
				return PacketTypes.REQUEST_RESULTS_CLIENT;
			}
			else if(input[1] == 1) {
				return PacketTypes.REQUEST_WORK_SERVER;
			}
		}
	
		return PacketTypes.NULL_PACKET;
	}
    
}
