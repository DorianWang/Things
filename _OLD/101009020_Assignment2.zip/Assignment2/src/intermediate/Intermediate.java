package intermediate;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Intermediate {
	public static final int BUFFER_SIZE = 4096; // Windows maximum path length is 260 characters, while Linux generally has a max of 4096.
	public static final int CLIENT_PORT = 23; // Port to interact with the client, also used for telnet apparently
	public static final int SERVER_PORT = 69; // Port to interact with the server
	
	//Code used from echo server
    DatagramPacket sentPacket, receivedPacket;
    DatagramSocket clientSocket, serverSocket;
    
    Intermediate(){
    	try {
    		serverSocket = new DatagramSocket();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
    	
    	try {
    		clientSocket = new DatagramSocket(CLIENT_PORT);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
    }
   
	/**
	 * 
	 * @param packetInput An array of bytes
	 * This function takes an array of bytes which will be printed out as a string of 
	 * characters as well as a space separated line of byte values.
	 */
	public void printPacket(byte[] packetInput) {
		System.out.print("String Version of Packet: ");
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print((char)packetInput[i]);
		}
		System.out.print("\n");
		System.out.print("Byte Version of Packet: ");
		
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print(packetInput[i]);
			System.out.print(" ");
		}
		System.out.print("\n");
	}
    
    /**
     * Main function of the class, loops forever and forwards packets received on port 23 to port 69 on the same device.
     * It will also print out all packets passing through.
     */
    public void run() {
    	while (true) {
    		
    		//Getting the packet from the client and forwarding it to the server
    		byte[] buffer = new byte[BUFFER_SIZE];
    		receivedPacket = new DatagramPacket(buffer, buffer.length);
    		
    		try {
    			clientSocket.receive(receivedPacket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(2);
			}
    		
    		
			byte[] input = new byte[receivedPacket.getLength()];
			System.arraycopy( buffer, 0, input, 0, receivedPacket.getLength() );
			System.out.println("\nPacket from Client:");
			this.printPacket(input);
			int clientport = receivedPacket.getPort();
    		
			try {
				sentPacket = new DatagramPacket(input, input.length,
						  InetAddress.getLocalHost(), SERVER_PORT);
			} catch (UnknownHostException e) {
				e.printStackTrace();
				System.exit(3);
			}
			  
			try {
				serverSocket.send(sentPacket);
			} catch (IOException e1) {
				e1.printStackTrace();
				System.exit(6);
			}
	      
			//Getting back the packet from the server and sending it to the client
			buffer = new byte[BUFFER_SIZE];
			receivedPacket = new DatagramPacket(buffer, buffer.length);

			try {
				serverSocket.receive(receivedPacket);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(4);
			}
			
			input = new byte[receivedPacket.getLength()];
			System.arraycopy( buffer, 0, input, 0, receivedPacket.getLength() );
			System.out.println("Packet from Server:");
			this.printPacket(input);
    		
			try {
				sentPacket = new DatagramPacket(buffer, receivedPacket.getLength(),
						  InetAddress.getLocalHost(), clientport);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(5);
			}
			
			try {
				clientSocket.send(sentPacket);
			} catch (IOException e1) {
				e1.printStackTrace();
				System.exit(7);
			}
    	
    	}
    }
	
	public static void main(String[] args) {
		System.out.println("Running Intermediate!");
		Intermediate inter = new Intermediate();
		inter.run();
	}

}
