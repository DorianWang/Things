package server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Server {
	public static final int BUFFER_SIZE = 4096; // Windows maximum path length is 260 characters, while Linux generally has a max of 4096.
	public static final int SERVER_PORT = 69; // Port to interact with the server, used for TFTP
	
	private static final byte[] readValue = {0, 3, 0, 1};
	private static final byte[] writeValue = {0, 4, 0, 0};
	
	DatagramSocket IOSocket;
    DatagramPacket sentPacket, receivedPacket;
	
	Server(){

	}
	
	/**
	 * This function checks received packet and returns an int based on what it is.
	 * @param buffer
	 * @return an integer with a value of 0 if the buffer is invalid, 1 if it is a read request, and 2 if it is a write request
	 */
	private int checkPacket(byte[] buffer) {
		if (buffer.length < 6) {
			System.out.println("Input is too short to check!");
			return 0;
		}
		int index = 2; int tempvalue = -1;
		if (buffer[0] != 0) {
			System.out.println("Input does not start with 0!");
			return 0;
		}
		
		if (buffer[1] == 1) {
			tempvalue = 1;
		} else if(buffer[1] == 2) {
			tempvalue = 2;
		} else {
			System.out.println("Input does have 1 or 2 as the second byte!");
			return 0;
		}

		
		for (;; index ++) { // Currently doesn't check if its actually a file name
			if (buffer[index] == (byte) 0) {
				break;
			}
			if (index > buffer.length - 4) {
				System.out.println("Input does not end the file name properly!");
				return 0;
			}
		}
		
		index++;
		
		for (;; index ++) { // Ditto here for the mode
			if (buffer[index] == (byte) 0) {
				break;
			}
			if (index == buffer.length - 1) {
				System.out.println("Input does not end the mode string properly!");
				return 0;
			}
		}
		if (index != buffer.length - 1) {
			System.out.println("Input does not end after the mode string!");
			return 0; // There is information after the 3rd 0, therefore packet is incorrect
		}
		
		return tempvalue;
	}
	
	
	/**
	 * 
	 * @param packetInput An array of bytes
	 * This function takes an array of bytes which will be printed out as a string of 
	 * characters as well as a space separated line of byte values.
	 */
	public void printPacket(byte[] packetInput) {
		System.out.print("String Version of Packet: ");
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print((char)packetInput[i]);
		}
		System.out.print("\n");
		System.out.print("Byte Version of Packet: ");
		
		for(int i = 0; i < packetInput.length; i++) {
			System.out.print(packetInput[i]);
			System.out.print(" ");
		}
		System.out.print("\n");
	}
	
	
	public void run() throws IOException, InterruptedException {
		while(true) {
			
			//Making socket and receiving packet
			try {
				IOSocket = new DatagramSocket(SERVER_PORT);
			} catch (SocketException e) {
				e.printStackTrace();
				System.exit(1);
			}
			byte[] buffer = new byte[BUFFER_SIZE];
			receivedPacket = new DatagramPacket(buffer, buffer.length);
			
			//Wait to get packets here
			try {
				IOSocket.receive(receivedPacket);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(2);
			}
			IOSocket.close(); // Close used up socket here, maybe not needed...
			
			// Trim down array to actual recieved amount
			byte[] input = new byte[receivedPacket.getLength()];
			System.arraycopy( buffer, 0, input, 0, receivedPacket.getLength() );
			
			System.out.println("\nReceived packet from intermediate:");
			this.printPacket(input);

			// Checks validity of received information and then sends back a message.
			switch(this.checkPacket(input)) {
			case 0:
				throw new IOException(); // Invalid input
			case 1:
				this.sentPacket = new DatagramPacket(readValue, readValue.length,
						receivedPacket.getAddress(), receivedPacket.getPort());
				break;
			case 2:
				this.sentPacket = new DatagramPacket(writeValue, writeValue.length,
						receivedPacket.getAddress(), receivedPacket.getPort());
				break;
			default:
				System.exit(4); // \o.o/ I dunno how we got here
			}
			
			Thread.sleep(2); // Slow it down a bit, it goes too fast :(
			
			//Sending a packet back to the intermediate
			System.out.println("Sending packet to intermediate:");
			try {
				DatagramSocket tempSocket = new DatagramSocket();
				tempSocket.send(this.sentPacket);
				tempSocket.close();
				printPacket(sentPacket.getData());
				
			} catch (SocketException e) {
				e.printStackTrace();
				System.exit(5);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(6);
			}
			
			//My code is a tragedy, and the world is a worse place with it existing...
		}
	}
	
	
	public static void main(String[] args) {

		System.out.println("Running Server");
		
		Server server = new Server();
		try {
			server.run();
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

}
