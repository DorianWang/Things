How to run
Run the Server program, the Intermediate program and the Client program in that order.
Other programs using port 23 or 69 can cause the execution to fail.
Output of the programs will be through standard output (console default).
If run in Eclipse the console output limit may need to be increased or removed.

The programs can also be run by running
java -jar X.jar
with X being the program name.

All code files are in the src folder, with subfolders for each.
All UML images have been placed in the root directory of the project.