package main;

import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

public class Agent implements Runnable{
	private Thread worker;
	private ServingTable table;
	
	private int testingDelay = 100; // Number of milliseconds to delay
	private final AtomicBoolean running = new AtomicBoolean(false);	

	Agent(ServingTable table){
		
		this.table = table;
	}
	
	public void start() {
		worker = new Thread(this);
        worker.start();
	}
	
	public void run() {
		this.running.set(true);
		Random randGen = new Random();
		
		while(this.running.get()) {
			
			try {
				Thread.sleep(testingDelay);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			int first = randGen.nextInt(3); // Get a number between 0 and 2
			int next =  (first + 1 + randGen.nextInt(2)) % 3; // Get a number between 1 and 2, and add it to the first generated value. This should leave either of the two other values.
			Ingredient a = Ingredient.convertIntToIngredient(first); Ingredient b = Ingredient.convertIntToIngredient(next); 
			System.out.println("Serving Ingredients " + a + " and " + b + "!");
			table.put(a, b);
		
		}
	}

	public void stop() {
		System.out.println("Stopping Agent!");
		this.running.set(false);
	}

	
	
}
