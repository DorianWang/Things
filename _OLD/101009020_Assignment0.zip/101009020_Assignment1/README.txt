The ServingTable file contains the class of the same name, which is the monitor, as well as the main() function.
The Chef file contains the chef class, which is the consumer.
The Agent file contains the agent class, which places the ingredients in the ServingTable.
The Ingredients file contains the ingredients enum.
Any references to a Colours file is just unremoved dead code.

In order to run the code load the .project file in eclipse.